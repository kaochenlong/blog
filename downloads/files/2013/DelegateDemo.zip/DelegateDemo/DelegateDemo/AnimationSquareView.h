//
//  AnimationSquareView.h
//  DelegateDemo
//
//  Created by 高見龍 on 13/5/26.
//  Copyright (c) 2013年 高思數位網路有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AnimationSquareView;
@protocol AnimationSquareViewDelegate <NSObject>

@optional
- (void) animationSquareView:(AnimationSquareView *) squareView didFinishAnimationWithStatus:(NSDictionary *)status;

@end

@interface AnimationSquareView : UIView

@property (nonatomic, weak) id <AnimationSquareViewDelegate> delegate;
- (void) run;

@end

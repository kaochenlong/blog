//
//  ViewController.m
//  DelegateDemo
//
//  Created by 高見龍 on 13/5/26.
//  Copyright (c) 2013年 高思數位網路有限公司. All rights reserved.
//

#import "ViewController.h"
#import "AnimationSquareView.h"

@interface ViewController()<AnimationSquareViewDelegate>

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    AnimationSquareView* squareView = [[AnimationSquareView alloc] initWithFrame:CGRectMake(50, 50, 100, 100)];
    [self.view addSubview:squareView];
    squareView.delegate = self;
    [squareView run];
}

#pragma mark - AnimationSquareView Delegate
- (void)animationSquareView:(AnimationSquareView *)squareView didFinishAnimationWithStatus:(NSDictionary *)status
{
    NSLog(@"current status = %@", status);
}

@end

//
//  ViewController.h
//  DelegateDemo
//
//  Created by 高見龍 on 13/5/26.
//  Copyright (c) 2013年 高思數位網路有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end

//
//  main.m
//  DelegateDemo
//
//  Created by 高見龍 on 13/5/26.
//  Copyright (c) 2013年 高思數位網路有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}

//
//  HelloWorldLayer.m
//  PlaySprite
//
//  Created by eddie on 2012/1/9.
//  Copyright 2012 高思數位網路有限公司. All rights reserved.
//

// Import the interfaces
#import "HelloWorldScene.h"

CCSprite *sprite;

// HelloWorld implementation
@implementation HelloWorld

+(id) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	HelloWorld *layer = [HelloWorld node];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}

// on "init" you need to initialize your instance
-(id) init
{
	if( (self=[super init] )) 
	{
		CGSize window_size = [[CCDirector sharedDirector] winSize];
		sprite = [CCSprite spriteWithFile:@"eddie_icon.png"];
		sprite.position = ccp(window_size.width / 2, window_size.height / 2);
		[self addChild:sprite];
		
		id move_me = [CCMoveBy actionWithDuration:0.5 position:ccp(100, 0)];
		id rotate_me = [CCRotateBy actionWithDuration:1 angle:360];
		
		[sprite runAction:[CCSequence actions:move_me, rotate_me, nil]];
		
	}
	return self;
}

// on "dealloc" you need to release all your retained objects
- (void) dealloc
{
	[super dealloc];
}
@end

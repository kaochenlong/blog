//
//  main.m
//  PlaySprite
//
//  Created by eddie on 2011/1/5.
//  Copyright 活動方塊網路股份有限公司 2011. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
	NSAutoreleasePool *pool = [NSAutoreleasePool new];
	int retVal = UIApplicationMain(argc, argv, nil, @"PlaySpriteAppDelegate");
	[pool release];
	return retVal;
}

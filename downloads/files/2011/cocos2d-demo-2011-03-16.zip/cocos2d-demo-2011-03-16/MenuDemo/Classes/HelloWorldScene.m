//
//  HelloWorldLayer.m
//  MenuDemo
//
//  Created by eddie on 2012/1/9.
//  Copyright 2012 高思數位網路有限公司. All rights reserved.
//

// Import the interfaces
#import "HelloWorldScene.h"
#import "CartScene.h"

// HelloWorld implementation
@implementation HelloWorld

+(id) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	HelloWorld *layer = [HelloWorld node];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}

// on "init" you need to initialize your instance
-(id) init
{
	if( (self=[super initWithColor:ccc4(255, 255, 255, 255)] )) 
	{
		CCMenuItemImage *btn1 = [CCMenuItemImage itemFromNormalImage:@"button1.png" selectedImage:@"button1.png" target:self selector:@selector(changeScene:)];
		CCMenuItemImage *btn2 = [CCMenuItemImage itemFromNormalImage:@"button2.png" selectedImage:@"button2.png"];
		CCMenuItemImage *btn3 = [CCMenuItemImage itemFromNormalImage:@"button3.png" selectedImage:@"button3.png"];
		CCMenu *menu = [CCMenu menuWithItems:btn1, btn2, btn3, nil];

		[menu alignItemsHorizontally];
		
		[self addChild:menu];
	}
	return self;
}

-(void) changeScene: (id) sender
{
	[[CCDirector sharedDirector] replaceScene:[CCTransitionFlipX transitionWithDuration:1 scene:[CartScene node]]];
}

// on "dealloc" you need to release all your retained objects
- (void) dealloc
{
	[super dealloc];
}
@end

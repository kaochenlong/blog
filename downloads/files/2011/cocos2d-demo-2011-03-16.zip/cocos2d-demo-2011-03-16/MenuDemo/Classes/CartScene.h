//
//  CartScene.h
//  MenuDemo
//
//  Created by eddie on 2012/1/9.
//  Copyright 2012 高思數位網路有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface CartScene : CCLayerColor 
{
	
}

+(id) scene;

@end

//
//  MenuDemoAppDelegate.h
//  MenuDemo
//
//  Created by eddie on 2012/1/9.
//  Copyright 2012 高思數位網路有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@class RootViewController;

@interface MenuDemoAppDelegate : NSObject <UIApplicationDelegate> {
	UIWindow			*window;
	RootViewController	*viewController;
}

@property (nonatomic, retain) UIWindow *window;

@end

//
//  CartScene.m
//  MenuDemo
//
//  Created by eddie on 2012/1/9.
//  Copyright 2012 高思數位網路有限公司. All rights reserved.
//

#import "CartScene.h"
#import "HelloWorldScene.h"

@implementation CartScene

+(id) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	CartScene *layer = [CartScene node];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}

-(id) init
{
	if( (self=[super initWithColor: ccc4(255, 255, 255, 255)] )) 
	{
		CCMenuItemImage *home = [CCMenuItemImage itemFromNormalImage:@"home.png" selectedImage:@"home.png" target:self selector:@selector(goHome:)];
		CCMenu *menu = [CCMenu menuWithItems:home, nil];
		
		[menu alignItemsVertically];
		
		[self addChild:menu];
	}
	return self;
}

-(void) goHome: (id) sender
{
	[[CCDirector sharedDirector] replaceScene:[CCTransitionPageTurn transitionWithDuration:1 scene:[HelloWorld node]]];
}

@end

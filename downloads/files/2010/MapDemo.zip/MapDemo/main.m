//
//  main.m
//  MapDemo
//
//  Created by eddie on 2010/12/11.
//  Copyright 2010 活動方塊網路股份有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}

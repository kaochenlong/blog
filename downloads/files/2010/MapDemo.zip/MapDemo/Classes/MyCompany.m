//
//  MyCompany.m
//  MapDemo
//
//  Created by eddie on 2012/1/9.
//  Copyright 2012 高思數位網路有限公司. All rights reserved.
//

#import "MyCompany.h"

@implementation MyCompany

@synthesize coordinate;
@synthesize title;
@synthesize subtitle;

-(id) initWithCoordinate: (CLLocationCoordinate2D) the_coordinate
{
	if (self = [super init])
	{
		coordinate = the_coordinate;
	}
	return self;
}

-(void) dealloc
{
	self.title = nil;
	self.subtitle = nil;
	[super dealloc];	
}

@end

//
//  MapDemoAppDelegate.h
//  MapDemo
//
//  Created by eddie on 2012/1/9.
//  Copyright 2012 高思數位網路有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MapDemoViewController;

@interface MapDemoAppDelegate : NSObject <UIApplicationDelegate> 
{
    UIWindow *window;
    MapDemoViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet MapDemoViewController *viewController;

@end


//
//  main.m
//  BMI
//
//  Created by eddie on 2010/11/23.
//  Copyright 2010 活動方塊網路股份有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}

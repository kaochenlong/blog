//
//  BMIAppDelegate.h
//  BMI
//
//  Created by eddie on 2012/1/9.
//  Copyright 2012 高思數位網路有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@class BMIViewController;

@interface BMIAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    BMIViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet BMIViewController *viewController;

@end


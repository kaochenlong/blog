//
//  BMIViewController.h
//  BMI
//
//  Created by eddie on 2012/1/9.
//  Copyright 2012 高思數位網路有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BMIViewController : UIViewController 
{
	IBOutlet UITextField *body_height;
	IBOutlet UITextField *body_weight;
	IBOutlet UILabel *result;
}

@property (nonatomic, retain) IBOutlet UITextField *body_height;
@property (nonatomic, retain) IBOutlet UITextField *body_weight;
@property (nonatomic, retain) IBOutlet UILabel *result;

-(IBAction) calcBMI: (id) sender;
-(IBAction) keyboardDismiss: (id) sender;
@end

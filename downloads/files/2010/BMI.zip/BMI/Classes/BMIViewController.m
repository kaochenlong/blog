//
//  BMIViewController.m
//  BMI
//
//  Created by eddie on 2012/1/9.
//  Copyright 2012 高思數位網路有限公司. All rights reserved.
//

#import "BMIViewController.h"

@implementation BMIViewController

@synthesize body_height;
@synthesize body_weight;
@synthesize result;

-(IBAction) calcBMI: (id) sender
{
	// 取得身高數值，並換算成公尺
	float height = [[body_height text] floatValue] / 100;
	
	// 取得體重數值
	float weight = [[body_weight text] floatValue];
	
	// 顯示計算結果
	result.hidden = NO;
	result.text = [NSString stringWithFormat:@"您的BMI值是：%.2f", (weight / (height * height))];
}

// 把鍵盤退下去
-(IBAction) keyboardDismiss: (id) sender
{
	[sender resignFirstResponder];
}

-(void) viewDidLoad
{
	// 設定這兩個欄位的初始為數字及標點符號鍵盤
	[body_height setKeyboardType:UIKeyboardTypeNumbersAndPunctuation];
	[body_weight setKeyboardType:UIKeyboardTypeNumbersAndPunctuation];
}

- (void)dealloc 
{
	[body_height release];
	[body_weight release];
	[result release];
    [super dealloc];
}

@end

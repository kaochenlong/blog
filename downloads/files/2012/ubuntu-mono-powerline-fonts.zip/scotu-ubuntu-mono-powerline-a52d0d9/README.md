# Ubuntu mono Powerline

Ubuntu Mono fonts patched for the "Powerline" vim plugin: https://github.com/Lokaltog/vim-powerline/

## How to use it

Assuming you already installed and configured vim-powerline:

    cd ~/.fonts/ && git clone https://github.com/scotu/ubuntu-mono-powerline.git && cd ~

